import React, { Component } from 'react';
import CropPopup from "./cropPopup";
import axios from 'axios';
class ImageHolder extends Component {
    constructor(props) {
        super(props);
        this.state = {
            croppedImageUrls: [],
            croppedFiles: [],
            uploadedData: [],
            uploadStatus: "",
            crop: [{ unit: 'px', width: 450, height: 755, name: "horizontal", display: false },
            { unit: 'px', width: 450, height: 365, name: "vertical", display: false },
            { unit: 'px', width: 380, height: 380, name: "gallery", display: false },

            { unit: 'px', width: 212, height: 365, name: "horizontal small", display: false }
            ]
        }
    }
    newCropvalue = (crop, val) => {
        let croped = this.state.crop;
        croped[val] = crop
        this.setState({ crop: croped });
    }
    onDimensionChange = (val) => {
        let cropdata = this.state.crop.map((each, index) => {
            if (index == val) {
                each.display = true;
                return each;
            } else {
                each.display = false;
                return each;
            }
        })
        this.setState({ crop: cropdata })
    }
    closePopup = () => {
        let cropdata = this.state.crop.map((each) => {
            each.display = false;
            return each;

        })
        this.setState({ crop: cropdata })
    }
    setCroppedImagesAndFiles = (urls, files) => {
        this.setState({ croppedImageUrls: urls, croppedFiles: files });
    }
    onimageUpload = () => {
        const data = new FormData()
        this.state.croppedFiles.map((each) => {
            data.append('file', each)
        })
        axios.post("http://localhost:3005/upload", data)
            .then(res => {
                if (res.statusText === "OK") {
                    this.setState({ uploadStatus: "success", uploadedData: res.data })
                }

            }).catch((err) => {
                this.setState({ uploadStatus: "failed" })
            })
        this.setState({ imageUploadStatus: true });
    }
    render() {
        return (<div>
            <p>Please Click on each box to crop Images according to mentioned dimesions to upload Files (Note:once you crop image to all the formats  Upload button gets enabed)</p>
            {this.state.crop.map((each, index) => {
                return <div key={index} className={each.name} onClick={this.onDimensionChange.bind(this, index)}>
                    {!this.state.croppedImageUrls[index] ? <p>{each.name + `Image with dimensons Width: ${each.width} Height: ${each.height}`} </p> :
                        <img alt="Crop" className={"imagedimensions"} src={this.state.croppedImageUrls[index]} />}
                    {each.display ? <CropPopup display={each.display} crop={each} val={index} src={this.props.src} selectedFile={this.props.selectedFile} imageExt={this.props.imageExt} newCropvalue={this.newCropvalue} setCroppedImagesAndFiles={this.setCroppedImagesAndFiles} closePopup={this.closePopup} croppedImageUrls={this.state.croppedImageUrls} croppedFiles={this.state.croppedFiles} /> : ''}

                </div>
            })}

            {this.state.croppedImageUrls.length && this.state.croppedImageUrls[0] && this.state.croppedImageUrls[1] && this.state.croppedImageUrls[2] && this.state.croppedImageUrls[3] ? <button name="Upload" value="upload" className="uploadButton" onClick={this.onimageUpload}>Upload</button> :
                <button name="Upload" value="upload" className="disabledButton" >Upload</button>}
            {this.state.uploadStatus === "success" && this.state.uploadedData.length ? <div>
                <p>Images Uploaded Successfully Following are the Images Uploaded</p>
                {this.state.uploadedData.map(each => {
                return <div className="uploadedFiles">
                    <p>{each.filename}</p>
                    <img alt={each.filename} style={{ maxWidth: '100%' }} src={each.filename} />
                </div>
            }) }</div>:  this.state.uploadStatus === "failed" ? <p>An error occured while Uploading images please try again</p>:""}
        </div>

        )
    }
}

export default ImageHolder;