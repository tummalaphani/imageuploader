import React, { Component } from 'react';
import { Modal } from "react-bootstrap";
import ReactCrop from 'react-image-crop';
class CropPopup extends Component {
    constructor(props) {
        super(props);
        this.state = { display: true }
    }
    onImageLoaded = image => {
        this.imageRef = image;
    };
    componentDidMount() {
        this.setState({ display: this.props.display })
    }
    dataURLtoBlob = (dataurl) => {
        var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
            bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
        while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
        }
        return new Blob([u8arr], { type: mime });
    }
    onCropComplete = (val, crop) => {
        this.makeClientCrop(crop, val);
    };

    onCropChange = (val, crop, percentCrop) => {
        // You could also use percentCrop:
        // this.setState({ crop: percentCrop });
        this.props.newCropvalue(crop, val);
    };

    async makeClientCrop(crop, val) {
        if (this.imageRef && crop.width && crop.height) {
            const croppedImageUrl = await this.getCroppedImg(
                this.imageRef,
                crop,
                `newFile_${crop.name}.jpeg`
            );
            let croppedImageUrls = this.props.croppedImageUrls;
            let croppedFiles = this.props.croppedFiles;
            let theBlob = this.dataURLtoBlob(croppedImageUrl);
            theBlob.lastModifiedDate = new Date();
            theBlob.name = this.props.crop.name + this.props.selectedFile.name;
            let newFile = new File([theBlob], this.props.crop.name + "_" + this.props.selectedFile.name, { type: "image/" + this.props.imageExt, lastModified: Date.now() });
            croppedFiles[val] = newFile;
            croppedImageUrls[val] = croppedImageUrl
            this.props.setCroppedImagesAndFiles(croppedImageUrls, croppedFiles);
        }
    }
    handleHide = () => {
        this.setState({ display: false })
        this.props.closePopup();
    }
    getCroppedImg(image, crop, fileName) {
        const canvas = document.createElement('canvas');
        const scaleX = image.naturalWidth / image.width;
        const scaleY = image.naturalHeight / image.height;
        canvas.width = crop.width;
        canvas.height = crop.height;
        const ctx = canvas.getContext('2d');

        ctx.drawImage(
            image,
            crop.x * scaleX,
            crop.y * scaleY,
            crop.width * scaleX,
            crop.height * scaleY,
            0,
            0,
            crop.width,
            crop.height
        );
        return canvas.toDataURL('image/' + this.props.imgSrcExt)
    }

    render() {
        return (
            <Modal
                show={this.state.display}
                onHide={this.handleHide}
                className="modal fade bo-configurator-modal"
                size="xl"
                backdrop="static"
            >
                <Modal.Header closeButton>
                    <h4 className="modal-title" >
                      {  this.props.selectedFile.name}
            </h4>
                </Modal.Header>
                <Modal.Body>
                    <ReactCrop
                        locked={true}
                        src={this.props.src}
                        crop={this.props.crop}
                        ruleOfThirds
                        onImageLoaded={this.onImageLoaded}
                        onComplete={this.onCropComplete.bind(this, this.props.val)}
                        onChange={this.onCropChange.bind(this, this.props.val)}
                    />
                </Modal.Body>
                {
                    <Modal.Footer>
                        <button name="save" value="save" onClick={this.handleHide}>save</button>
                    </Modal.Footer>
                }
            </Modal>
        )
    }
}

export default CropPopup;