import React, { Component } from 'react';
import { Modal } from "react-bootstrap";

class PreViewImage extends Component {
    constructor(props) {
        super(props);
        this.state = { display: true }
    }
    componentDidMount() {
        this.setState({ display: this.props.display })
    }
    handleHide = () => {
        this.setState({ display: false })
        this.props.closePreView();
    }


    render() {
        return (
            <Modal
                show={this.state.display}
                onHide={this.handleHide}
                className="modal fade bo-configurator-modal"
                size="xl"
                backdrop="static"
            >
                <Modal.Header closeButton>
                    <h4 className="modal-title" >
                        Image PreView
            </h4>
                </Modal.Header>
                <Modal.Body>
                    <img alt="preview" style={{ maxWidth: '100%' }} src={this.props.src} /> }
          </Modal.Body>
                {
                    <Modal.Footer>

                    </Modal.Footer>
                }
            </Modal>
        )
    }
}

export default PreViewImage;