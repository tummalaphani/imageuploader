import { AuthenticationContext, adalFetch, withAdalLogin } from 'react-adal';
 
export const adalConfig = {
  redirect_uri:'http://localhost:3000/',
  scope:'"https://www.googleapis.com/auth/drive"',
  clientId: '51970043971-daae08m75pmcectl0h202damdllv21ae.apps.googleusercontent.com',
  endpoints: {
    api: "https://accounts.google.com/o/oauth2/v2/auth",
  },
  cacheLocation: 'localStorage',
  navigateToLoginRequestUrl: true
};
 
export const authContext = new AuthenticationContext(adalConfig);
export const adalApiFetch = (fetch, url, options) =>
  adalFetch(authContext, adalConfig.endpoints.api, fetch, url, options);
 
export const withAdalLoginApi = withAdalLogin(authContext, adalConfig.endpoints.api);