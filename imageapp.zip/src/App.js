import React, { Component } from 'react';
import ImageHolder from './CropImage/imageHolder';
import 'react-image-crop/dist/ReactCrop.css';
import './App.css';
import PreViewImage from "./CropImage/preViewImage";

export default class App extends Component {
  state = {
    src: null,
    selectedFile: null,
    imageExt: null,
    displayPreview: false,
    imageUploadStatus: false,

  };
  closePreView = () => {
    this.setState({ displayPreview: false })
  }
  showPreView = () => {
    this.setState({ displayPreview: true })
  }
  onSelectFile = e => {

    if (e.target.files && e.target.files.length > 0) {
      let selectedFile = e.target.files[0];
      console.log(selectedFile, "file")
      const reader = new FileReader();
      if (e.target.files[0].type.indexOf("image") == -1) {
        alert("Invalid Type Please select only Image files with dimensions 1024/1024");
        this.setState({ src: "", imageExt: "", selectedFile: "", croppedImageUrls: [], croppedFiles: [], imageUploadStatus: false, displayPreview: false })
        return false;
      }
      reader.readAsDataURL(e.target.files[0]);
      let imageExt = e.target.files[0].name.split('.').pop();
      console.log(imageExt, "imageExt")
      reader.onload = function (e) {
        var image = new Image();
        image.src = e.target.result;
        image.onload = function () {
          var height = image.height;
          var width = image.width;

          if (height === 1024 || width === 1024) {
            this.setState({ src: reader.result, imageExt: imageExt, selectedFile: selectedFile, croppedImageUrls: [], croppedFiles: [] })
            return true;

          } else {
            this.setState({ src: "", imageExt: "", selectedFile: "", croppedImageUrls: [], croppedFiles: [], imageUploadStatus: false, displayPreview: false })
            alert("Height and Width must be equal to 1024px.");
            return false;
          }

        }.bind(this)

      }.bind(this);

    } else {
      this.setState({ src: "", imageExt: "", selectedFile: "", croppedImageUrls: [], croppedFiles: [], imageUploadStatus: false, displayPreview: false })
    }
  };

  // If you setState the crop in here you should return false.

  render() {
    const { src } = this.state;

    return (
      <div className="App">
        <div>
          <input type="file" accept="image/*" onChange={this.onSelectFile} />

        </div>
        <div>
          {src ? <p onClick={this.showPreView}>Click here to preview the uploaded image</p> : ""}
          {src && this.state.displayPreview ? <PreViewImage src={src} display={this.state.displayPreview} closePreView={this.closePreView} /> : ""}
        </div>

        {src ? <ImageHolder key={this.state.selectedFile.name} src={this.state.src} selectedFile={this.state.selectedFile} imageExt={this.state.imageExt}
        /> : ""}
      </div>)
  }
}
